export class UserClass{

    id:number=0;
    
    fullname:string="";
    
    mobile:string="";
    
    email:string="";
    password:string=""
    }